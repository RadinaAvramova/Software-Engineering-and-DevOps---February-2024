Student App for SoftUni
Add Jenkinsfile
